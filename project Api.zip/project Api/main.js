const apiUrl = 'https://api.weather.gov/gridpoints/MTR/84,105/forecast';

fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
        displayWeatherData(data);
    })
    .catch(error => {
        console.error('Error fetching weather data:', error);
    });

function displayWeatherData(data) {
    const weatherDataContainer = document.getElementById('weather-data');
    const periods = data.properties.periods;

    periods.forEach(period => {
        const date = new Date(period.startTime);
        const date2 = new Date(period.endTime);

        // Options for formatting the date and time
        const options = {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "numeric",
            second: "numeric",
            timeZoneName: "short",
        };

        // Format the date and time
        const formattedStartTime = date.toLocaleDateString("en-US", options);
        const formattedEndTime = date2.toLocaleDateString("en-US", options);

        const tableRow = document.createElement('tr');
        tableRow.innerHTML = `
            <td>${period.name}</td>
            <td>${period.shortForecast}</td>
            <td>${period.detailedForecast}</td>
            <td>${formattedStartTime}</td>
            <td>${formattedEndTime}</td>
            <td>${period.temperature} ${period.temperatureUnit}</td>
            <td>${period.windSpeed}, ${period.windDirection}</td>
            <td><img src="${period.icon}" alt="${period.shortForecast}" class="img-fluid"></td>
        `;

        weatherDataContainer.appendChild(tableRow);
    });
}
